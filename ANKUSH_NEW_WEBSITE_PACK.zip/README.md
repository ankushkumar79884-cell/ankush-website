# ANKUSH Website

Complete static portfolio website.

## Upload
Upload the entire contents of this folder to the root of your GitHub Pages repository.

## Structure
- index.html
- projects/jarvis.html
- projects/game.html
- projects/web-lab.html
- projects/profile.html

No build tools or external libraries are required.
